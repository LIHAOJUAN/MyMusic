package testdemo.leiyu.com.music;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private  ListView list;
    private String music_name;
    private  List<String> data=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView textView = (TextView) findViewById(R.id.button3);
        Typeface tface = Typeface.createFromAsset(getAssets(),"GinⅡa Sans Regular.otf");
        textView.setTypeface(tface);

        list=(ListView)findViewById(R.id.list3);
        this.setdata();

        //list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data));
        Button bt=(Button)findViewById(R.id.button3);

        bt.setOnClickListener(v->{
            list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data));
        });
        //add Eventlistener to listview
        list.setOnItemClickListener((a, b, c, d) -> {
            music_name= data.get(c);
            //Alart box for user selection
            new AlertDialog.Builder(this).setTitle("You wanna play 《" + music_name + " 》?")
                    .setIcon(android.R.drawable.ic_dialog_info)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            send_data();

                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).show();
        });
    }
    //Set song name
    public  void setdata(){
        data.add("对面的女孩看过来");
        data.add("不要认为自己没有用");
        data.add("You're Never Over");
        data.add("The Internet Millionaires' Club");
        data.add("Eminem - Not Afraid_audio");
    }
    //Put selected song into the second interface
    public void send_data(){
        Intent intent=new Intent(this,Main2Activity.class);
        intent.putExtra("data",music_name);
        this.startActivity(intent);
    }
}
