package testdemo.leiyu.com.music;

import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private String name="";
    private MediaPlayer player = new MediaPlayer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView textView = (TextView) findViewById(R.id.textView);
        Typeface tface = Typeface.createFromAsset(getAssets(),"GinⅡa Sans Regular.otf");
        textView.setTypeface(tface);

        //Selected song name
        name=this.getIntent().getStringExtra("data");

        Button bt1=(Button)findViewById(R.id.button);
        Button bt2=(Button)findViewById(R.id.button2);
        Button bt3=(Button)findViewById(R.id.button4);
        TextView tt=(TextView)findViewById(R.id.textView);
        ImageView iv= (ImageView)findViewById(R.id.imageView);
        //Spliced song URL address
        String url="http://mpianatra.com/Courses/files/"+name+".mp3";

        try {



            //add a Eventlistener to the play button
            bt1.setOnClickListener(v -> {
                try {
                    this.play(url);
                    tt.setText(name + " is playing!");
                    bt1.setEnabled(false);
                    bt2.setEnabled(true);
                    bt3.setEnabled(true);

                    //change picture
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.note));


                }catch(Exception e){Toast.makeText(this,"please check internet!",Toast.LENGTH_LONG).show();
                    tt.setText("Please check your network connection");}
            });

            //add a Eventlistener to the pause button
            bt2.setOnClickListener(v->{
                if(player.isPlaying()){
                    player.pause();
                    tt.setText(name+" is paused!");
                    bt2.setText("Continue");
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.sus));

                }else{
                    player.start();
                    tt.setText(name+" is playing!");
                    bt2.setText("suspend");
                    bt1.setEnabled(false);//Click on the pause button while you are not allowed to hit the play button
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.note));
                }
            });
            //add a Eventlistener to the stop button
            bt3.setOnClickListener(v->{

                player.stop();

                tt.setText(name+" is stoped!");
                bt1.setEnabled(true);
                bt2.setEnabled(false);//Click the stop button, and you are not allowed to hit the pause button
                bt3.setEnabled(false);
                iv.setImageDrawable(getResources().getDrawable(R.drawable.fcd));

            });


        }catch (Exception e){
            //Catch exceptions, broken network, the song does not exist, etc.
            Toast.makeText(this,"please check internet!",Toast.LENGTH_LONG).show();
            tt.setText("Please check your network connection");
            return;
        }



    }

    @Override
    protected void onStop() {
        super.onStop();
        player.release();
    }

    public  void play(String url) throws  Exception{
        player.reset();
        //Load song
        player.setDataSource(this,Uri.parse(url));
        //Prepare songs
        player.prepare();
        player.start();
    }

}
